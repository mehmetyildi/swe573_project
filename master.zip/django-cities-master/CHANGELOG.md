# Change Log
All notable changes to this project will (may?) be documented in this file.

## [Unreleased][unreleased]
### Changed
- added ``cities.plugin.reset_queries.Plugin`` that calls reset_queries randomly (default chance is 0.000002 per imported city or district). See CITIES_PLUGINS in Configuration example for details
- It's now possible to specify several files to be downloaded and processed. See Configuration example for details.

## [0.4.1] - 2014-07-06

- Last version without changelog.